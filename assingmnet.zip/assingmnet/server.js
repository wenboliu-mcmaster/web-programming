// Required packages
var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

// Return the teacher page
app.get('/auction', function(req,res){
  res.sendFile(__dirname + '/auction.html');
});

// Return the student page
app.get('/bidder', function(req,res){
  res.sendFile(__dirname + '/bidder.html');
});

// Variable for storing the actual correct answer
var correctanswer;
var topbidder;

// If we have a connection....
io.on('connection', function(socket){

  socket.on("submitauction", function(quesdata)
  {
    // Set the correct answer
   // correctanswer = quesdata.answer;
    topbidder=quesdata.price;

    // Make sure we've received the question OK
    console.log("auction submitted: " + JSON.stringify(quesdata));
   
    // Broadcast the question to all the students
    io.emit("deliverauction", quesdata);}); 

  socket.on("submitbid", function(newbid){

    // Send back the result (right or wrong), along with 
    // the right answer
    var topbid={};

    //io.to(socket.id).emit("resultquestion",
    	//                  {correct: (correctanswer == answerdata),
    //	                   answer: correctanswer});
    if (topbidder<newbid.amount) {
      topbidder=newbid.amount;
      topbid.amount=topbidder;
      topbid.name=newbid.name;    

    io.emit("updatebid", topbid);  } ; }); });

// Start the server
http.listen(3000, function(){
  console.log('listening on *:3000');
});

