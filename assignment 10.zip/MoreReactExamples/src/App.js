import React, { Component } from 'react';
import './App.css';
import {
  HashRouter as Router,
  Route,
  Link,
  NavLink
} from 'react-router-dom';



class Form extends React.Component
{

  constructor(props)
  {
    super(props);
    this.state =
    {  flagstate:true,
      input: "",
      itemindex:0,
      lists: 
        [
          {task: "prepare exam 1", id: Date.now()},
              
        ]  
    };
  }

  deleteItem(id){
    const filteredItems= this.state.lists.filter(item =>
      item.id!==id);
    this.setState({
      lists: filteredItems
    })

  }
  
  setUpdate(id){
    console.log("items:"+this.state.lists);

    
    const editItem=this.state.lists.filter(item=> item.id===id )[0];
    this.state.itemindex=this.state.lists.findIndex(item=> item==editItem);
  
   
    this.setState({
      
      input:editItem.task,
      flagstate:false,
      
    });
    //this.deleteItem(id);
    
    
  }
  inputStateChange(event) {
    this.setState({input: event.target.value});
  }

  submitFunc() {
    let listArray=this.state.lists;
    if (this.state.input!==""&& this.state.flagstate){
      listArray.push({task:this.state.input, id:Date.now()});
    } 
    else if (!this.state.flagstate){
      listArray.splice(this.state.itemindex,1,{task:this.state.input, id:Date.now()});
    } 
   
    
    this.setState({
     
      lists:listArray,
      input: "",
      flagstate:true,
    });
   
  }
  renderlist(lists) { 
    
    return <li key={lists.id}   ><strong> <a onClick={this.setUpdate.bind(this,lists.id)} >E </a> </strong>
     task: {lists.task}
     <strong><a onClick={this.deleteItem.bind(this,lists.id)} >D </a> </strong> </li>;
}
  render() {
   

    return (
      <div>
        <h1>  Add a  todo</h1>
          <input type="text" onChange={this.inputStateChange.bind(this)}
               value={this.state.input} />
          <button onClick={this.submitFunc.bind(this)}>{this.state.flagstate?'Add':'Edit'}</button>
        
          <  h3>TODO list           
        
                <ul> 
                {this.state.lists.map(this.renderlist.bind(this))}         
                </ul>      

          </h3>
      </div>
    );
  }
};

class Home extends React.Component 
{  
  render () 
  {      
    return ( <p>Some home content</p> );
  }    
};
class DeleteForm extends React.Component 
{  
  render () 
  {      
    return (  <p>URL parm: {this.props.match.params.someid} </p> );
  }    
};

class About extends React.Component 
{  
  render () 
  {      
    return ( <p>Some about content</p> );
  }    
};

class TODO extends React.Component 
{  
  render () 
  {      
    return ( <p>TODO list. </p> );
  }    
};

class Contact extends React.Component 
{  
  render () 
  {      
    return ( <p>Some contact content</p> );
  }    
};

class App extends Component {
  render() {
    return (
    <Router>
      <div>
     
         <ul>
           
            <li><NavLink exact to="/">Home</NavLink></li>
            <li><NavLink to="/about">About</NavLink></li>
            <li><NavLink to="/contact">Contact</NavLink></li>
            <li><NavLink to="/TODO">TODO</NavLink></li>
          
            
            
          </ul>
          <Route exact path="/" component={Home}/>
          <Route path="/about" component={About}/>
          <Route path="/contact" component={Contact}/>
          <Route path="/TODO" component={Form}/>  
          <Route path="/urlparm/:someid" component={DeleteForm}/>

      </div>
      </Router>
    );
  }
}

export default App;
